
package sockets.server.network;

import sockets.server.controller.ServerController;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ForkJoinPool;


public class GameHandler implements Runnable{
   // private final Socket playerSocket;
   // private PrintWriter outToPlayer;
  //  private BufferedReader inFromPlayer;
  //  private final boolean autoFlush = true;
    private boolean  connected = false;
    private ServerController serverController;
    private String dataToPlayer;
    private static int numberOfPlayers = 0;
    private  SocketChannel socketChannel;
    private final ByteBuffer msgFromClient = ByteBuffer.allocateDirect(8000);
    private boolean firstTime = true;
    private ByteBuffer buffer;
    private String string;
    private boolean completedProcess = false;

    public GameHandler(SocketChannel socketChannel) {
        this.socketChannel = socketChannel;
        serverController = new ServerController();
        this.connected=true;
    }

    @Override
    public void run(){
        String userInput = string;
        try{
            if(firstTime){
                dataToPlayer = serverController.intro();
                buffer = ByteBuffer.wrap(dataToPlayer.getBytes());
                socketChannel.write(buffer);
                firstTime=false;
            }
            while (connected && userInput != null && !completedProcess ){
                dataToPlayer =serverController.checkUserInput(userInput);
                buffer = ByteBuffer.wrap(dataToPlayer.getBytes());
                socketChannel.write(buffer);
                completedProcess = true;
            }
        } catch(IOException e){
            System.out.println("GameHandler !!! "+e.getMessage());
        }
    }

    public void ReceiveFromClient() throws IOException {
        msgFromClient.clear();
        if (socketChannel.read(msgFromClient)==-1){
            System.out.println("Game Handler has a message");
        }
        msgFromClient.flip();
        byte[] bytes = new byte[msgFromClient.remaining()];
        msgFromClient.get(bytes);
        string = new String(bytes);
        ForkJoinPool.commonPool().execute(this);
        completedProcess = false;
    }

    public void SendToClient() throws IOException {
        completedProcess = false;
        ForkJoinPool.commonPool().execute(this);
    }

    public void DisConnect() throws IOException{
        socketChannel.close();
    }
}





//            numberOfPlayers++;
//            System.out.println("Player joined The Game");
//            System.out.println("Number of players in the game: " + numberOfPlayers);
//            outToPlayer = new PrintWriter(new OutputStreamWriter(playerSocket.getOutputStream()),autoFlush);
//            inFromPlayer = new BufferedReader(new InputStreamReader(playerSocket.getInputStream()));
//
//            String userInput;
//            serverController = new ServerController();
//            serverController.intro(outToPlayer);
//
//            while(connected && ((userInput = inFromPlayer.readLine())!=null)){
//
//                if(userInput.startsWith("exit") && userInput.length()==4){
//                    System.out.println("Client Left The Game");
//                    numberOfPlayers--;
//                    serverController.disconnect(playerSocket);
//                    connected = false;
//                }
//                else{
//                    serverController.checkUserInput(userInput,outToPlayer);
//                }
//            }