/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.server.start;

import sockets.server.network.ServerNetwork;

public class ServerStarter {
   
    public static void main(String[] args){
       
        ServerNetwork serverNetwork = new ServerNetwork();
        serverNetwork.serve();
              
    }
    
}
