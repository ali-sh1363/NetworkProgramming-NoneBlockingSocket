/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.view;


import sockets.client.network.ClientNetwork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClientInterpreter implements Runnable{
    

    private ClientNetwork clientNetwork;
    private ConsoleOutput screenHandler;
    private BufferedReader console;
    private static boolean ThreadStarted = false;
    

    @Override
    public void run() {

        ThreadStarted = true;
        clientNetwork = new ClientNetwork();
        console = new BufferedReader(new InputStreamReader(System.in));
        String command;
        screenHandler = new ConsoleOutput();
        clientNetwork.connect(screenHandler);

        while (ThreadStarted) {
            try {

                command = console.readLine().toLowerCase();
                if (command.startsWith("exit") && command.length() == 4) {
                    clientNetwork.DisConnect();
                    ThreadStarted = false;
                } else {
                    clientNetwork.SendMessage(command);
                }

            } catch (IOException e) {
                System.out.println("ClientInterPerter !!! " + e.getMessage());
            }
        }
    }
}
