/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.network;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;

public class ClientNetwork implements Runnable {

    private Selector selector;
    private InetSocketAddress serverAddress;
    private SocketChannel socketChannel;
    private boolean connected = false;
    private volatile boolean timeToSend = false;
    private OutputHandler screenHandler;
    private ByteBuffer FromServerBuffer = ByteBuffer.allocateDirect(8192);
    private Queue<ByteBuffer> messagesToSend = new ArrayDeque<>();
    private String dataToServer;


    public void connect(OutputHandler screenHandler) {
        this.screenHandler = screenHandler;
        serverAddress = new InetSocketAddress(6000);
        new Thread(this).start();
        System.out.println("client is connecting");
    }

    @Override
    public void run() {
        try {
            selector = Selector.open();
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(false);
            socketChannel.connect(serverAddress);
            socketChannel.register(selector, SelectionKey.OP_CONNECT);
            connected = true;
            while (connected) {
                if (timeToSend) {
                    socketChannel.keyFor(selector).interestOps(SelectionKey.OP_WRITE);
                    timeToSend = false;
                }
                selector.select();
                for (SelectionKey key : selector.selectedKeys()) {
                    selector.selectedKeys().remove(key);
                    if (!key.isValid()) {
                        continue;
                    }
                    if (key.isConnectable()) {
                        socketChannel.finishConnect();
                        key.interestOps(SelectionKey.OP_READ);
                        screenHandler.messageOnScreen("Player is Connected Now");

                    } else if (key.isReadable()) {
                        FromServerBuffer.clear();
                        if (socketChannel.read(FromServerBuffer) != -1) {
                            FromServerBuffer.flip();
                            byte[] bytes = new byte[FromServerBuffer.remaining()];
                            FromServerBuffer.get(bytes);
                            String receivedMessage = new String(bytes);
                            NotifyMessageReceived(receivedMessage, screenHandler);
                        } else {
                            System.out.println("Connection is  not readable");
                        }
                    } else if (key.isWritable()) {
                        ByteBuffer toServerBuffer;
                        toServerBuffer = ByteBuffer.wrap(dataToServer.getBytes());
                        socketChannel.write(toServerBuffer);
                        key.interestOps(SelectionKey.OP_READ);
                        synchronized (messagesToSend) {
                            while ((toServerBuffer = messagesToSend.peek()) != null) {
                                socketChannel.write(toServerBuffer);
                                if (toServerBuffer.hasRemaining()) {
                                    return;
                                }
                                messagesToSend.remove();
                            }
                            key.interestOps(SelectionKey.OP_READ);
                        }
                    } else {
                        System.out.println("is not Writable ");
                    }
                }
            }
            socketChannel.close();
            socketChannel.keyFor(selector).cancel();

        } catch (IOException e) {
            System.out.println("Client Network !!!" + e.getMessage());
        }
    }

    private void NotifyMessageReceived(String message, OutputHandler screenHandler) {
        Executor pool = ForkJoinPool.commonPool();
        pool.execute(new Runnable() {
            @Override
            public void run() {
                screenHandler.messageOnScreen(message);
            }
        });
    }

    public void SendMessage(String charGuess) {
        if (connected) {
            dataToServer = charGuess;
            timeToSend = true;
            selector.wakeup();
        } else {
            System.out.println("SendMessage");
        }
    }

    public void DisConnect() {
        if (connected) {
            SendMessage("exit");
            connected = false;
        }
    }
}