
package sockets.server.network;

import sockets.server.controller.ServerController;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ForkJoinPool;


public class GameHandler implements Runnable{

    private boolean  connected = false;
    private ServerController serverController;
    private String dataToPlayer;
    private  SocketChannel socketChannel;
    private final ByteBuffer msgFromClient = ByteBuffer.allocateDirect(8000);
    private boolean firstTime = true;
    private ByteBuffer buffer;
    private String string;
    private boolean completedProcess = false;

    public GameHandler(SocketChannel socketChannel) {
        this.socketChannel = socketChannel;
        serverController = new ServerController();
        this.connected=true;
    }
    @Override
    public void run(){
        String userInput = string;
        try{
            if(firstTime){
                dataToPlayer = serverController.intro();
                buffer = ByteBuffer.wrap(dataToPlayer.getBytes());
                socketChannel.write(buffer);
                firstTime=false;
            }
            while (connected && userInput != null && !completedProcess ){
                dataToPlayer =serverController.checkUserInput(userInput);
                buffer = ByteBuffer.wrap(dataToPlayer.getBytes());
                socketChannel.write(buffer);
                completedProcess = true;
            }
        } catch(IOException e){
            System.out.println("GameHandler !!! "+e.getMessage());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void ReceiveFromClient() throws IOException {
        msgFromClient.clear();
        if (socketChannel.read(msgFromClient) == -1){
            System.out.println("player has left");
            socketChannel.close();
        }
        msgFromClient.flip();
        byte[] bytes = new byte[msgFromClient.remaining()];
        msgFromClient.get(bytes);
        string = new String(bytes);
        ForkJoinPool.commonPool().execute(this);
        completedProcess = false;
    }
    public void SendToClient() throws IOException {
        completedProcess = false;
        ForkJoinPool.commonPool().execute(this);
    }
    public void DisConnect() throws IOException{
        socketChannel.close();
    }
}
