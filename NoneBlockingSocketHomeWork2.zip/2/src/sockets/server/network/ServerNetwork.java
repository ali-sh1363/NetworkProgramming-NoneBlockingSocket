
package sockets.server.network;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class ServerNetwork {
    private Selector selector;
    private ServerSocketChannel serverSocketChannel;
    private ServerSocket serverSocket;
    private boolean timeToBroadcast;
    private SocketChannel socketChannel;
    private Set keySet;
    private Iterator keyIterator;
    private SelectionKey key;


    public void serve(){
        try{
            selector = Selector.open();
            serverSocketChannel = ServerSocketChannel.open();
            serverSocket = serverSocketChannel.socket();
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.bind(new InetSocketAddress(6000));
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
            System.out.println("server is Connecting !!!");

            while (true){
                selector.select();
                keySet = selector.selectedKeys();
                keyIterator = keySet.iterator();
                while (keyIterator.hasNext()) {
                    key = (SelectionKey) keyIterator.next();
                    keyIterator.remove();
                    if (!key.isValid()) {
                        System.out.println("print some thing");
                        continue;
                    }if (key.isAcceptable()){
                        serverSocketChannel = (ServerSocketChannel) key.channel();
                        SocketChannel socketChannel = serverSocketChannel.accept();
                        socketChannel.configureBlocking(false);
                        GameHandler gameHandler = new GameHandler(socketChannel);
                        socketChannel.register(selector,SelectionKey.OP_WRITE,gameHandler);

                    }else if (key.isReadable()){
                                socketChannel = (SocketChannel) key.channel();
                               GameHandler gameHandler = (GameHandler) key.attachment();
                        try {
                                gameHandler.ReceiveFromClient();
                        }catch (IOException e){
                            System.out.println("ServerNetwork isReadable !!! "+e.getMessage());
                            gameHandler.DisConnect();
                            key.cancel();
                        }
                    }else if(key.isWritable()){
                        socketChannel = (SocketChannel) key.channel();
                        GameHandler gameHandler = (GameHandler) key.attachment();
                        try {
                            gameHandler.SendToClient();
                            key.interestOps(SelectionKey.OP_READ);
                        }catch (IOException e){
                            System.out.println("ServerNetwork isWritable !!!" + e.getMessage());
                            gameHandler.DisConnect();
                            key.cancel();
                        }
                    }
                }
            }
        }catch (IOException e){
            System.out.println("Server Network !!! "+e.getMessage());
        }
    }
}
