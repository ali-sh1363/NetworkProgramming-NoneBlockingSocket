package sockets.server.controller;


import sockets.server.model.Hangman;
import sockets.server.model.RandomWord;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import static java.lang.Character.isLetter;

public class ServerController  {


    private boolean isStarted = false;
    private boolean isMiddle = false;
    private boolean flag = false;
    private Hangman hangmanGame;
    private StringBuilder wordScreen;
    private static final char SHOW_SCREEN = '_';
    private char guessChar;
    private String dataToPlayer;
    private static final String STRING_SEPARATOR = "#";


    public String intro () throws IOException{
        return (new Hangman().showIntro());
    }


    public String checkUserInput(String userInput) throws IOException, InterruptedException {
        if(userInput.startsWith("start") && userInput.length()==5){
            if (!isStarted){
                if(!isMiddle){

                    CompletableFuture.runAsync(() -> {
                        RandomWord findWord = new RandomWord();
                        String chosenWord = findWord.getTheWord();
                        wordScreen = new StringBuilder(chosenWord);
                        for (int i = 0; i < wordScreen.length(); i++){
                            wordScreen.setCharAt(i, SHOW_SCREEN);
                        }
                        hangmanGame = new Hangman(chosenWord, chosenWord.length());
                    });
                    try {
                        Thread.sleep(100);
                    }catch (InterruptedException e){

                    }
                    dataToPlayer = "\n=======================================================================\n";
                    try {
                        dataToPlayer += hangmanGame.showState(wordScreen);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    isStarted = true;
                }
                else{
                    dataToPlayer = hangmanGame.showState(wordScreen);
                    isMiddle = false;
                    isStarted = true;
                }
            }
            else{
                if (!isMiddle){
                    dataToPlayer = "\nYou started the game already!!!\n";
                    dataToPlayer += hangmanGame.showState(wordScreen);
                }
            }
        }
        else{
            if(userInput.length()==0){//ok
                dataToPlayer = "\nYou didn't type anything or you are typing too fast!!!!\n";
            }
            else{
                guessChar = userInput.charAt(0);
                if( (userInput.length()==1) && (isLetter(guessChar)) && (isStarted == true) && (!isMiddle) ){

                    dataToPlayer = hangmanGame.hangmanCheckChar(guessChar, wordScreen);
                    if(dataToPlayer.indexOf(STRING_SEPARATOR)!= -1){
                        String[] temp = dataToPlayer.split(STRING_SEPARATOR);
                        dataToPlayer = temp[0];
                        wordScreen = new StringBuilder(temp[1]);
                    }
                    else{
                        wordScreen = new StringBuilder(dataToPlayer);
                        flag = true;
                    }
                    if(!hangmanGame.gameWinLoseState && !flag){
                        dataToPlayer += "\n";
                        dataToPlayer += hangmanGame.showState(wordScreen);
                    }
                    else if(!hangmanGame.gameWinLoseState && flag){
                        dataToPlayer = "\n";
                        dataToPlayer += hangmanGame.showState(wordScreen);
                        flag = false;
                    }
                    else{
                        dataToPlayer += "\nIf you want to continue write START command. Unless write EXIT...\n";
                        isMiddle = true;
                        isStarted = false;
                        hangmanGame.gameWinLoseState = false;
                    }
                }
                else if ( (userInput.length()==1) && (!isLetter(guessChar))&& (isStarted == true) && (!isMiddle)){
                    dataToPlayer = "\nInvalid character! You should try a letter between a-z! Try again...\n";
                    dataToPlayer += hangmanGame.showState(wordScreen);
                }
                else{
                    dataToPlayer = "\nInvalid command! Try again...\n";
                    if ((isStarted) && (!isMiddle)){
                        dataToPlayer += hangmanGame.showState(wordScreen);
                    }
                }
            }
        }
        return dataToPlayer;
    }
}
